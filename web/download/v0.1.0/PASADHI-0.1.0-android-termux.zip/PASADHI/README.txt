PASADHI 0.1.0 - android-termux

pkg install python
python -m pip install -r requirements.txt
bash pasadhi.sh

Open http://127.0.0.1:8765 after starting. Ctrl+C stops the service.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
Android requires Termux; this archive is not an APK.
