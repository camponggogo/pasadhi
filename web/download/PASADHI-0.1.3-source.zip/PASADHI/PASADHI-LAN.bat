@echo off
cd /d "%~dp0"
python -m pasadhi.app.service --lan %*
pause
