@echo off
cd /d "%~dp0"
python -m pasadhi.app.service --host 0.0.0.0 %*
pause
