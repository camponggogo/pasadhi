PASADHI 0.1.3 - android-termux

pkg install python
python -m pip install -r requirements.txt
bash pasadhi.sh

Open http://127.0.0.1:8765/dashboard for the coordinator overview. All page URLs are printed at startup. Ctrl+C stops the service.
All main launchers enable LAN by default: PASADHI.bat on Windows, pasadhi.sh on Linux/Termux, PASADHI.command on macOS. Run the main launcher on EVERY computer. Python bundles: install requirements.txt first. LAN nodes are discovered automatically without worker IP lists.
For localhost-only access, pass --host 127.0.0.1 to the launcher. Legacy LAN-named launchers remain compatibility aliases. Allow the application TCP port and multicast UDP 5353 only on the intended trusted LAN.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
Android requires Termux; this archive is not an APK.
