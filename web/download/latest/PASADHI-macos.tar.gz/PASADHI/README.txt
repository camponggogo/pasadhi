PASADHI 0.1.2 - macos

python3 -m pip install -r requirements.txt
sh PASADHI.command

Open http://127.0.0.1:8765 after starting. Ctrl+C stops the service.
Language: automatic browser detection or choose English, Thai, Chinese, Japanese, Spanish, French or German in the app header. The choice is remembered in this browser; translations work offline.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.

0.1.2: create earnings directory before first write; worker retries storage errors.
