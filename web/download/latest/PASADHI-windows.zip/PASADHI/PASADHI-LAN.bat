@echo off
cd /d "%~dp0"
pasadhi.exe --host 0.0.0.0 %*
pause
