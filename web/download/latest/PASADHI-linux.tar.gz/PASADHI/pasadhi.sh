#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 -m pasadhi.app.service --port "${PASADHI_PORT:-8766}" "$@"
