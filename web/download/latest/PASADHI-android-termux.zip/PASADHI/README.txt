PASADHI 0.1.2 - android-termux

pkg install python
python -m pip install -r requirements.txt
bash pasadhi.sh

Open http://127.0.0.1:8765 after starting. Ctrl+C stops the service.
Language: automatic browser detection or choose English, Thai, Chinese, Japanese, Spanish, French or German in the app header. The choice is remembered in this browser; translations work offline.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
Android requires Termux; this archive is not an APK.

0.1.2: create earnings directory before first write; worker retries storage errors.
