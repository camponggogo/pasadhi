PASADHI 0.1.0 - source

python3 -m pip install -r requirements.txt
sh pasadhi.sh

Open http://127.0.0.1:8765 after starting. Ctrl+C stops the service.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
