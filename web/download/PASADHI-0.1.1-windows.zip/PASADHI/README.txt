PASADHI 0.1.1 - windows

Double-click PASADHI.bat. No Python installation needed.

Open http://127.0.0.1:8765 after starting. Ctrl+C stops the service.
Language: automatic browser detection or choose English, Thai, Chinese, Japanese, Spanish, French or German in the app header. The choice is remembered in this browser; translations work offline.
Standalone Windows x64 executable; unsigned.
