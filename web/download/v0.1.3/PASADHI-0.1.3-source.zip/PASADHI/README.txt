PASADHI 0.1.3 - source

python3 -m pip install -r requirements.txt
sh pasadhi.sh

Open http://127.0.0.1:8765/dashboard for the coordinator overview. All page URLs are printed at startup. Ctrl+C stops the service.
Copy .env.example to .env to configure LAN binding, worker URLs and a stable DNS URL. DNS records must be configured on your router or DNS server.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
