PASADHI 0.1.3 - macos

python3 -m pip install -r requirements.txt
sh PASADHI.command

Open http://127.0.0.1:8765/dashboard for the coordinator overview. All page URLs are printed at startup. Ctrl+C stops the service.
To see all PASADHI computers, use PASADHI-LAN.bat on Windows, pasadhi-lan.sh on Linux/Termux, or PASADHI-LAN.command on macOS on EVERY computer. Python bundles: install requirements.txt first. LAN nodes are discovered automatically without worker IP lists.
Default launchers announce presence but keep HTTP on localhost; those nodes appear as LAN disabled until restarted in LAN mode. Allow the application TCP port and multicast UDP 5353 only on the intended trusted LAN.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
