#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec sh ./PASADHI.command --lan "$@"
