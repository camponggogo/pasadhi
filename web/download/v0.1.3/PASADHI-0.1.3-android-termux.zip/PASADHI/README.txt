PASADHI 0.1.3 - android-termux

pkg install python
python -m pip install -r requirements.txt
bash pasadhi.sh

Open http://127.0.0.1:8765/dashboard for the coordinator overview. All page URLs are printed at startup. Ctrl+C stops the service.
Copy .env.example to .env to configure LAN binding, worker URLs and a stable DNS URL. DNS records must be configured on your router or DNS server.
Python source distribution; Python 3.10+ required. psutil enables full hardware probing.
Android requires Termux; this archive is not an APK.
